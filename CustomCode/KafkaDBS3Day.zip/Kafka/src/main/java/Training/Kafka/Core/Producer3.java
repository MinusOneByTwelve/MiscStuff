package Training.Kafka.Core;

import java.util.*;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class Producer3 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"91.203.132.139:3400,91.203.135.190:3400,91.203.135.225:3400,91.203.135.226:3400");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.PARTITIONER_CLASS_CONFIG,TweetPartitioner.class.getName());
        
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config);
        
        ProducerRecord<String, String> PR = new ProducerRecord<String, String>("tweetdata","US","message1");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});
        PR = new ProducerRecord<String, String>("tweetdata","UK","message2");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});
        PR = new ProducerRecord<String, String>("tweetdata","IN","message3");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});        
        PR = new ProducerRecord<String, String>("tweetdata","SL","message4");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});
        PR = new ProducerRecord<String, String>("tweetdata","BT","message5");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});
        PR = new ProducerRecord<String, String>("tweetdata","JP","message6");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});        
        PR = new ProducerRecord<String, String>("tweetdata","RU","message7");
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}else {System.out.println("Error : "+Ex.toString());}}});        
                  
        KP.flush();
        KP.close();
    }
}