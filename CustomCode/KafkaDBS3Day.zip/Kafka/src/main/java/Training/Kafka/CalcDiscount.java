package Training.Kafka;

import io.confluent.ksql.function.udf.Udf;
import io.confluent.ksql.function.udf.UdfDescription;

@UdfDescription(
    name = "getdiscount",
    description = "discount on total price",
    version = "0.1.0",
    author = "somecoder"
)

public class CalcDiscount {


    @Udf(description = "enter total price")
    public double getdiscount(final double totalprice) {

        return totalprice * .9;
    }
}