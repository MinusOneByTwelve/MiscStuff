package Training.Kafka.Core;

import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.InvalidRecordException;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.utils.Utils;

public class TweetPartitioner implements Partitioner {

    public void configure(Map<String, ?> configs) {
        
    }

    public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
    	
        if ((keyBytes == null) || (!(key instanceof String)))
            throw new InvalidRecordException("All messages must have keys");
        
        int p = 0;
        
        
        List<PartitionInfo> partitions = cluster.partitionsForTopic(topic);
        int numPartitions = partitions.size();
        /*int sp = (int) Math.abs(numPartitions * 0.4);

        if (((String) key).equals("IN") || ((String) key).equals("SL") || ((String) key).equals("BT"))
            p = Utils.toPositive(Utils.murmur2(valueBytes)) % sp;
        else
            p = Utils.toPositive(Utils.murmur2(keyBytes)) % (numPartitions - sp) + sp;*/
        

        if (((String) key).equals("IN") || ((String) key).equals("SL") || ((String) key).equals("BT"))
            p = 1;
        else if (((String) key).equals("US") || ((String) key).equals("UK"))
            p = 2;        
        else
            p = 0;
        
        System.out.println("Key = " + (String) key + " Partition = " + p);
        return p;
    }

    public void close() {
    }
}