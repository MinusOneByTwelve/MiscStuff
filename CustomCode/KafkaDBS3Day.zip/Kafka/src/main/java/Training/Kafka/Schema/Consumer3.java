package Training.Kafka.Schema;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import Training.Kafka.*;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

public class Consumer3 {

	public void run() {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers","216.48.187.251:3400,216.48.179.60:3400,216.48.182.63:3400,216.48.182.109:3400");
        properties.put("group.id", "Consumer3");
        properties.put("auto.commit.enable", "false");
        properties.put("auto.offset.reset", "earliest");
        properties.setProperty("key.deserializer", StringDeserializer.class.getName());
        properties.setProperty("value.deserializer", KafkaAvroDeserializer.class.getName());
        properties.setProperty("schema.registry.url", "http://216.48.180.137:3500");
        properties.setProperty("specific.avro.reader", "true");

        KafkaConsumer<String, Customer> KC = new KafkaConsumer<>(properties);
        String topic = "Customer";
        KC.subscribe(Collections.singleton(topic));

        System.out.println("Waiting for data...");

        while (true){
            System.out.println("Polling");
            ConsumerRecords<String, Customer> records = KC.poll(Duration.ofMillis(1000));

            for (ConsumerRecord<String, Customer> record : records){
                Customer customer = record.value();
                System.out.println(customer);
            }

            KC.commitSync();
        }
    }
}
