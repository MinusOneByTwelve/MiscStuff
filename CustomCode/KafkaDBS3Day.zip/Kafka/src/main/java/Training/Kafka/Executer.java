package Training.Kafka;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.PropertyConfigurator;

import Training.Kafka.Core.*;
import Training.Kafka.Schema.*;
//import Training.Kafka.Stream.*;

public class Executer {

	public static void main(String[] args) throws InterruptedException, ExecutionException, IOException {
		//PropertyConfigurator.configure("C:\\eclipse\\workspace\\LearnKafka\\resources\\log4j.properties");
		PropertyConfigurator.configure("/media/prathamos/Work/Work/Training/Kafka/Kafka/resources/log4j.properties");
		
		//new Producer0().run();
		//new Producer0_0().run();
		//new Producer1().run();
		//new Producer3().run();
		//new Producer4().run();
		//new Producer5().run();		
		//new SecuritiesProducer().run();
		
		//new Consumer0().run();
		//new Consumer1().run();
		//new Consumer2().run();
		//new Consumer3().run();		
		//new Consumer4().run();
		//new SecuritiesConsumer().run();
		
		//new PuttingPetrolIntoFire().run();
				
		/*ExecutorService executorService = Executors.newFixedThreadPool(2);
        for (int i = 0; i < 2; i++) {
            if(i ==0){executorService.execute(() -> {try {new _GlobalOrdersProducer().run();} catch (InterruptedException | ExecutionException e) {}});}
            else if(i ==1){executorService.execute(() -> {new RetailCurrencySolve().run();});}
            Thread.sleep(1000);
        }
        executorService.awaitTermination(1, TimeUnit.MINUTES);*/		

		/*ExecutorService executorService = Executors.newFixedThreadPool(2);
        for (int i = 0; i < 2; i++) {
            if(i ==0){executorService.execute(() -> {try {new _WordCountProducer().run();} catch (InterruptedException | ExecutionException e) {}});}
            else if(i ==1){executorService.execute(() -> {new StrmWrdCnt().run();});}
            Thread.sleep(1000);
        }
        executorService.awaitTermination(1, TimeUnit.MINUTES);*/
		
        /*ExecutorService executorService = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 4; i++) {
            if(i ==0)
            {
            executorService.execute(() -> {
				try {
					new _ElectionResultsProducer().run();
				} catch (ExecutionException | InterruptedException e) {
					e.printStackTrace();
				}
			});
            }
            else if(i ==1)
            {
            executorService.execute(() -> {
            	new AbkiBaar_Sarkar().run();
			});
            }
            else if(i ==2)
            {
            executorService.execute(() -> {
            	new AbkiBaar_Sarkar().run();
			});
            }            
            else {executorService.execute(() -> {
				new AbkiBaar_Sarkar().run();
			});}
            Thread.sleep(1000);
        }
        executorService.awaitTermination(5, TimeUnit.MINUTES);*/
		
		//new StopChernobyl().run();	
		
		//new StrmJoin().run();		
	}
}
