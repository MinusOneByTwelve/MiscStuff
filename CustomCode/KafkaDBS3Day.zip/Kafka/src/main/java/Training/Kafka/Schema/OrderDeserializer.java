package Training.Kafka.Schema;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.Map;
import org.apache.kafka.common.serialization.Deserializer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OrderDeserializer implements Deserializer<Order> {
	 @Override public void close() {
	 }
	 @Override public void configure(Map<String, ?> arg0, boolean arg1) {
	 }
	 @Override
	 public Order deserialize(String arg0, byte[] arg1) {
	   Order order = null;
	   
	   /*ObjectMapper mapper = new ObjectMapper();
	   try {
		   order = mapper.readValue(arg1, Order.class);
	   } catch (Exception e) {
	     e.printStackTrace();
	   }*/

	   ByteArrayInputStream bis = new ByteArrayInputStream(arg1);
	   ObjectInput in = null;
	   try {
	     in = new ObjectInputStream(bis);
	     Object o = in.readObject(); 
	     order = (Order) o ;
	   } catch (IOException | ClassNotFoundException e) {e.printStackTrace();
	} finally {
	     try {
	       if (in != null) {
	         in.close();
	       }
	     } catch (IOException ex) {}
	   }
	   
	   return order;
	 }
	}