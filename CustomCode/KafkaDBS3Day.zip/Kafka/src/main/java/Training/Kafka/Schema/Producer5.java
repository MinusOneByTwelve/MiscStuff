package Training.Kafka.Schema;

import java.util.*;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class Producer5 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"164.52.213.124:3400,164.52.213.123:3400,164.52.212.201:3400,164.52.212.190:3400");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,OrderSerializer.class.getName());
        
        KafkaProducer<String, Order> KP = new KafkaProducer<String, Order>(Config);
        
        Order o = new Order();
        o.setOrderId(5656);
        o.setItemName("LED TV");
        o.setAmountTotal(100000);
        o.setItemDesc("LG");
        ProducerRecord<String, Order> PR = new ProducerRecord<String, Order>("Orders","cvcvvb",o);
        KP.send(PR, new Callback() {public void onCompletion(RecordMetadata RMD, Exception Ex) 
        {if(Ex == null){System.out.println("Info Recieved: \n"+"Partition:"+RMD.partition()+ "\n"+"Offset:"+RMD.offset()+ "\n");}
        else {System.out.println("Error : "+Ex.toString());}}});

        KP.flush();
        KP.close();
    }
}
