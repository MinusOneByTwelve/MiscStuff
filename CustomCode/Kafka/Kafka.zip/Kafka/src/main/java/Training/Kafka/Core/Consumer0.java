package Training.Kafka.Core;

import java.time.Duration;
import java.util.*;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

public class Consumer0 
{
    public void run()
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"164.52.213.124:3400,164.52.213.123:3400,164.52.212.201:3400,164.52.212.190:3400");
        Config.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        Config.setProperty(ConsumerConfig.GROUP_ID_CONFIG,"ey7");
        Config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        //Config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"latest");
        //discuss consumer heartbeat
        
        KafkaConsumer<String, String> KC = new KafkaConsumer<String, String>(Config);
        
        KC.subscribe(Arrays.asList("TopicX"));
        //KC.subscribe(Arrays.asList("reuters","bbc","rt"));
               
        while(true) {
        	ConsumerRecords<String,String> CRS = KC.poll(Duration.ofMillis(100));
	        	for(ConsumerRecord<String,String> CR : CRS) {
					System.out.println(
							"Key : "+CR.key()+ " "+
							"Value : "+CR.value()+ " "+
							"Partition : "+CR.partition()+ " "+
							"Offset:"+CR.offset()+ "\n");
	        	}
        }
    }
}
