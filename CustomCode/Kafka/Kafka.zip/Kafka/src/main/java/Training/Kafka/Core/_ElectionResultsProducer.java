package Training.Kafka.Core;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class _ElectionResultsProducer {
	private static int GetRandomNumber(int F, int S) {

		return (int)(Math.random() * ((S - F) + 1)) + F;
	}
	
	public void run() throws ExecutionException, InterruptedException {

        String bootstrapServers = "91.203.132.139:3400,91.203.135.190:3400,91.203.135.225:3400,91.203.135.226:3400";

        Properties properties = new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);
        
        String[] Parties = {"BJP", "INC", "SPP", "BSP", "RLP", "CPI", "BTP", "AAP", "RLD", "OTH"};
        String[] Districts = {"Ganganagar", "Hanumangarh", "Bikaner", "Churu", "Jhunjhunu", "Sikar", 
        		"Jaipur", "Alwar", "Bharatpur", "Dholpur", "Karauli", "Dausa", "Sawai Madhopur","Tonk", "Ajmer", 
        		"Nagaur", "Pali", "Jodhpur", "Jaisalmer", "Barmer", "Jalore", "Sirohi", "Udaipur", 
        		"Pratapgarh", "Banswara", "Chittorgarh", "Pratapgarh", "Rajsamand", 
        		"Bhilwara", "Bundi", "Kota", "Baran", "Jhalawar"};
        Random r = new Random();
        
        for (int i=0; i<=10000; i++ ) {
        	TimeUnit.MILLISECONDS.sleep(2500);
            String topic = "Elections";
            String Lead = Integer.toString(GetRandomNumber(1, 5));
            String District = Districts[r.nextInt(Districts.length)];
            String Party = Parties[r.nextInt(Parties.length)];            

            ProducerRecord<String, String> record =
                    new ProducerRecord<String, String>(topic, District, Party+"-"+Lead);

            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if (e == null) {
                        System.out.println("MetaData Generated... \n" +
                                "Topic:" + recordMetadata.topic() + "\n" +
                                "Partition: " + recordMetadata.partition() + "\n" +
                                "Offset: " + recordMetadata.offset() + "\n" +
                                "Timestamp: " + recordMetadata.timestamp());
                    } else {
                    	System.out.println("Exception : "+ e.toString());
                    }
                }
            });
        }

        producer.flush();
        producer.close();
    }
}