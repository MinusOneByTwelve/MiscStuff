package Training.Kafka.Stream;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.util.Properties;

public class StrmJoin {

	public void run() {
        final Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "StrmJoin");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "91.203.132.139:3400,91.203.135.190:3400,91.203.135.225:3400,91.203.135.226:3400");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());      
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
           
        StreamsBuilder streamsBuilder = new StreamsBuilder();
        KStream<String, String> KS0 = streamsBuilder.stream("ReqOTP",Consumed.with(Serdes.String(), Serdes.String()));
        KStream<String, String> KS1 = streamsBuilder.stream("RepOTP",Consumed.with(Serdes.String(), Serdes.String()));

        ValueJoiner<String, String, String> VJ = (KS0_V, KS1_V) -> {
            return KS0_V.equals(KS1_V) ? "Success" : "Failure";
        };
        
        KStream<String, String> KS3 = KS0.join(KS1,VJ,
        	      JoinWindows.ofTimeDifferenceWithNoGrace(Duration.ofSeconds(10)));
        	 
        KS3.to("ResOTP"); 
        
        /*KTable<String, String> KT0 = streamsBuilder.table("ReqOTP",Consumed.with(Serdes.String(), Serdes.String()));
        KTable<String, String> KT1 = streamsBuilder.table("RepOTP",Consumed.with(Serdes.String(), Serdes.String()));       
        KStream<String, String> KS4 = KT0.join(KT1, (v1, v2) -> {
            return v1.equals(v2) ? "Success" : "Failure";
        }).toStream();
        
        GlobalKTable<String, String> GKT = streamsBuilder.globalTable("UserMaster",Consumed.with(Serdes.String(), Serdes.String()));
        KStream<String, String> KS5 = streamsBuilder.stream("UserTrans",Consumed.with(Serdes.String(), Serdes.String()));
        KStream<String, String> KS6 = KS5.join(GKT, (k, v) -> k, (v1, v2) -> v1+v2);
        
        KStream<String, String> KS7 = KS5.leftJoin(GKT, (k, v) -> k, (v1, v2) -> {
        	if(v2!=null) {return v2;}
        	return v1;
        	});*/        
        
        KafkaStreams streams = new KafkaStreams(streamsBuilder.build(), props);
        streams.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {streams.close();}));
    }
}