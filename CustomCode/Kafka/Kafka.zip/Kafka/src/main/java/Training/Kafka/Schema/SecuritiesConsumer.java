package Training.Kafka.Schema;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.serialization.StringDeserializer;

import Training.Kafka.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

public class SecuritiesConsumer {

	public void run() throws IOException {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers","216.48.187.251:3400,216.48.179.60:3400,216.48.182.63:3400,216.48.182.109:3400");
        properties.put("group.id", "SecuritiesConsumer");
        properties.put("auto.commit.enable", "false");
        properties.put("auto.offset.reset", "earliest");
        properties.setProperty("key.deserializer", StringDeserializer.class.getName());
        properties.setProperty("value.deserializer", KafkaAvroDeserializer.class.getName());
        properties.setProperty("schema.registry.url", "http://164.52.218.174:3500");
        properties.setProperty("specific.avro.reader", "true");

        KafkaConsumer<String, GenericRecord> KC = new KafkaConsumer<>(properties);
        String topic = "Security";
        KC.subscribe(Collections.singleton(topic));

        while (true){
            ConsumerRecords<String, GenericRecord> records = KC.poll(Duration.ofMillis(1000));

            for (ConsumerRecord<String, GenericRecord> record : records){
            	int TypeOfRecord = -1;
            	
            	for (final Header header : record.headers()) {
            		if (new String(header.value(), StandardCharsets.UTF_8).equals("MF")) {TypeOfRecord = 0;} else {TypeOfRecord = 1;}
            	  } 
            	
            	if(TypeOfRecord == 0){MF mf = (MF) record.value();System.out.println(mf);}
            	if(TypeOfRecord == 1){Shares share = (Shares) record.value();System.out.println(share);}            	
            }

            KC.commitSync();
        }
    }
}