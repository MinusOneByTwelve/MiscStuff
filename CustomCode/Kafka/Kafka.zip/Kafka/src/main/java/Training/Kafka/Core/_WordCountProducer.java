package Training.Kafka.Core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class _WordCountProducer 
{
    public String[] readLines(String filename) throws IOException 
    {
        FileReader fileReader = new FileReader(filename);
         
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        List<String> lines = new ArrayList<String>();
        String line = null;
         
        while ((line = bufferedReader.readLine()) != null) 
        {
            lines.add(line);
        }
         
        bufferedReader.close();
         
        return lines.toArray(new String[lines.size()]);
    }
    
    public void run() throws InterruptedException, ExecutionException
    {
    	Properties Config = new Properties();
        
        Config.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"91.203.132.139:3400,91.203.135.190:3400,91.203.135.225:3400,91.203.135.226:3400");
        Config.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        Config.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
 
        KafkaProducer<String, String> KP = new KafkaProducer<String, String>(Config);
        
        String filename = "/media/prathamos/Work/Work/Training/Kafka/Shakespeare.txt";
        
        try
        {
            String[] lines = readLines(filename);
         
            for (String line : lines) 
            {
            	TimeUnit.MILLISECONDS.sleep(500);
    	        ProducerRecord<String, String> PR = 
    	        		new ProducerRecord<String, String>("TopicX", line);
    	        KP.send(PR, new Callback() {
    				public void onCompletion(RecordMetadata RMD, Exception Ex) {
    					if(Ex == null)
    					{
    						System.out.println("Info Recieved: \n"+
    								"Partition:"+RMD.partition()+ "\n"+
    								"Offset:"+RMD.offset());
    					}
    					else {System.out.println("Error : "+Ex.toString());}
    				}
    	        });
            }
        }
        catch(IOException e){System.out.println(e.getMessage());}        
        
        KP.flush();
        KP.close();
    }
}
