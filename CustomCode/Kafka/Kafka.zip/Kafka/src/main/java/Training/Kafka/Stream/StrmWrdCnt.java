package Training.Kafka.Stream;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

public final class StrmWrdCnt {

    public Topology MakeTopology(){
		StreamsBuilder builder = new StreamsBuilder();
		
		// Step 1 -> create stream from kafka	
		KStream<String, String> source = builder.stream("TopicX");
		//KStream<String, MyOwnCustomSerializer> source = builder.stream("therequiredtopic", Consumed.with(Serdes.String(), MyOwnCustomSerializer));
		// Step 2 -> convert words to lowercase
		/*KStream<String, String> V1 = source.mapValues(textLine -> textLine.toLowerCase());
		KStream<String, String> V2 = V1.flatMapValues(textLine -> Arrays.asList(textLine.split("\\W+")));
		KGroupedStream<Object, String> V3 = V2.groupBy((key, value) -> value);*/
		
		KTable<String, Long> counts = source.mapValues(textLine -> textLine.toLowerCase())
		// Step 3 -> flatten word structure
		.flatMapValues(textLine -> Arrays.asList(textLine.split("\\W+")))
		// Step 4 -> group the words by name
		.groupBy((key, value) -> value)	
		// Step 5 -> count occurences
		.count();
		// Step 6 -> save counts to kafka
		//callmywebapi
        counts.toStream().filter((key, value) -> value != null).to("TopicY", 
        		Produced.with(Serdes.String(), Serdes.Long()));		
		
		return builder.build();
    }
    
	public void run() {
        final Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "StrmWrdCnt");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "91.203.132.139:3400,91.203.135.190:3400,91.203.135.225:3400,91.203.135.226:3400");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        //props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class); 
        //props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class);        
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        //props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, "3");
        //Exactly Once Semantics
        //props.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE);
        
        final KafkaStreams streams = new KafkaStreams(MakeTopology(), props);
        final CountDownLatch latch = new CountDownLatch(1);

        Runtime.getRuntime().addShutdownHook(new Thread("StrmWrdCntStop") {
            @Override
            public void run() {
            	streams.close();
                latch.countDown();
            }
        });

        try {
            streams.start();   
            //Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
            latch.await();            
            while(true){
                streams.localThreadsMetadata().forEach(data -> System.out.println(data));
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }            
        } catch (final Throwable e) {
            System.exit(1);
        }
        System.exit(0);
    }
}