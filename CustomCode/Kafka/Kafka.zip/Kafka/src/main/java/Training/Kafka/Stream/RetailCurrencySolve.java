package Training.Kafka.Stream;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Arrays;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

public final class RetailCurrencySolve {

    public Topology MakeTopology(){
		StreamsBuilder builder = new StreamsBuilder();
		
		KStream<String, String> source = builder.stream("Payment");
		KStream<String, String> k2 = source.mapValues(textLine -> ConversionRate(textLine));
		k2.filter((key, value) -> value != null).to("RealPayment", 
        		Produced.with(Serdes.String(), Serdes.String()));	
		
		return builder.build();
    }
    
	private static int GetRandomNumber(int F, int S) {

		return (int)(Math.random() * ((S - F) + 1)) + F;
	}  
	
	private String ConversionRate(String v)
    {
    	String[] splits = v.split(",");
        
        return "訂單號 : " + splits[0] + " 產品編號 : " + splits[1] + " 數量 : " + 
        Math.round(Float.parseFloat(splits[2])*GetRandomNumber(10,25)*Math.random()) + " 人民幣";
    }	

	public void run() {
        final Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "RetailCurrencySolve");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "164.52.215.125:3400,164.52.215.127:3400,164.52.215.131:3400,164.52.215.133:3400");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        //props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class); 
        //props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, MyOwnCustomORAvroSerializer.class);        
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        //props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, "3");
        //Exactly Once Semantics
        //props.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE);
        
        final KafkaStreams streams = new KafkaStreams(MakeTopology(), props);//TRANSFORMATION
        final CountDownLatch latch = new CountDownLatch(1);

        Runtime.getRuntime().addShutdownHook(new Thread("RetailCurrencySolveStop") {
            @Override
            public void run() {
            	streams.close();
                latch.countDown();
            }
        });

        try {
            streams.start(); //ACTION   
            //Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
            latch.await();            
            while(true){
                streams.localThreadsMetadata().forEach(data -> System.out.println(data));
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }            
        } catch (final Throwable e) {
            System.exit(1);
        }
        System.exit(0);
    }
}